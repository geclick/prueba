//
//  loginViewController.swift
//  Ejemplo
//
//  Created by leodanys on 2/7/16.
//  Copyright © 2016 leodanys. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
