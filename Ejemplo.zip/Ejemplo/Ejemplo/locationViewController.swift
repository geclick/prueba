//
//  locationViewController.swift
//  Ejemplo
//
//  Created by leodanys on 2/7/16.
//  Copyright © 2016 leodanys. All rights reserved.
//

import UIKit
import MapKit

class LocationViewController: UIViewController, MKMapViewDelegate{
    
    weak var vistaMapa: MKMapView?
    var locationManager: CLLocationManager?
    //var posicionesPersonas: [MKPointAnnotation] = []
    //var datosRecibidos = NSMutableData()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        //var personaInfo = NSDictionary()
        //var listaAux = Array<MKPointAnnotation>()
        
        //var latitud: CLLocationDegrees?
        //var longitud: CLLocationDegrees?
        
        //let punto = MKPointAnnotation()
        //var dictGeo = NSDictionary()
        
        //var urlJson = "http://10.25.38.58/users.json"
        
        //let respuesta = NSMutableURLRequest(URL: (NSURL(string: "http://10.25.38.58/users.json"))!)
        //let connection = NSURLConnection(request: respuesta, delegate: self)
        //let config = NSURLSessionConfiguration.defaultSessionConfiguration()
        //let datosRecibidos =
        //let session = NSURLSession.sharedSession().dataTaskWithURL(NSURL(string: "http://10.25.38.58/users.json")!)
        //{ (data, response, error) in
            //do {
                //print("ESTA ES LA RESPUESTA \(data)")
                //let arrayDatosJson = try NSJSONSerialization.JSONObjectWithData(data!, options: []) as! NSArray
                //print("ESTA ES EL ARRAY JSON \(arrayDatosJson)")
                
                //varible que almacena el diccionario de una persona
                
                //var dicLong = NSDictionary()
                //self.posicionesPersonas = []
                
                /*for persona in arrayDatosJson{
                    personaInfo = persona as! NSDictionary
                    
                    punto.title = personaInfo["name"] as? String
                    
                    dictGeo = personaInfo["address"]!["geo"] as! NSDictionary
                    //longitud = personaInfo["address"]!["geo"]["lat"]
                    
                    latitud = CLLocationDegrees(Double(dictGeo["lat"]! as! String)!)
                    longitud = CLLocationDegrees(Double(dictGeo["lng"]! as! String)!)
                    
                    punto.coordinate = CLLocationCoordinate2D(latitude: latitud!, longitude: longitud!)
                    
                    //vistaMapa?.addAnnotation(punto)
                    //self.posicionesPersonas.append(punto)
                    listaAux.append(punto)
                    //print("Esta persona se llama \(personaInfo["name"]!) y vive en latitud\(dictGeo["lat"]!) y longitud \(dictGeo["lng"]!)")
                    //print(punto.title)
                }
            }
            catch{
                print("Explote")
            }
        //print(listaAux)
        }
        
        session.resume()*/
       
        
        vistaMapa = MKMapView(frame: view.frame)
        vistaMapa?.delegate = self
        vistaMapa?.showsUserLocation = true
        
        view.addSubview(vistaMapa!)
        
    }
    
    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)
        locationManager = CLLocationManager()
        locationManager?.requestWhenInUseAuthorization()
    }

    func mapView(mapView: MKMapView, didUpdateUserLocation userLocation: MKUserLocation) {
        let regionAMostrar = MKCoordinateRegionMakeWithDistance(userLocation.coordinate, 500, 500)
        mapView.setRegion(regionAMostrar, animated: true)
    }
    
 
}
