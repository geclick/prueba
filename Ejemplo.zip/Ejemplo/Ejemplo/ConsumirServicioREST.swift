//
//  ConsumirServicioREST.swift
//  Ejemplo
//
//  Created by leodanys on 2/14/16.
//  Copyright © 2016 leodanys. All rights reserved.
//

import UIKit

class ConsumirServicioRest: UIViewController, UITableViewDataSource{
    
    //tableView
    var tableView: UITableView!
    
    //lista para ir guardando los datos de las personas del JSON
    var listaAux: [String] = []
    
    override func viewDidLoad() {
        self.tableView = UITableView(frame: self.view.frame, style: .Grouped)
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        self.tableView.dataSource = self
        super.viewDidLoad()
        
        //dicionario con los datos de una persona
        var personaInfo = NSDictionary()
        
        //dicionario para guardar latitud y longitud de las personas del JSON
        var dictGeo = NSDictionary()
        
        //variable para guardar el nombre completode la persona
        var nombrePersona:[String] = []
        
        //se probo con el JSON descargado y publicado localmente, esta es la direccion original
        let url = NSURL(string: "https://jsonplaceholder.typicode.com/users")!
        
        //let url = NSURL(string: "http://10.25.38.58/users.json")!
        
        if let datosRecibidos = NSData(contentsOfURL: url){
            do {
                if let arrayDatosJson = try NSJSONSerialization.JSONObjectWithData(datosRecibidos, options: []) as? NSArray{
                    
                    for persona in arrayDatosJson{
                        personaInfo = persona as! NSDictionary
                    
                        dictGeo = personaInfo["address"]!["geo"] as! NSDictionary
                        nombrePersona = (personaInfo["name"] as! String).componentsSeparatedByString(" ")
                        
                        
                        //si el nombre contiene Mr. o Mrs. lo ignoro
                        //un nombre Mr. Pedro Perez al hacerle split quedaria
                        //["Mrs.", "Pedro", "Perez"]
                        if nombrePersona.count > 2{
                           self.listaAux.append("\(nombrePersona[1]), \(dictGeo["lat"]!), \(dictGeo["lng"]!)")
                        }
                        else{
                            self.listaAux.append("\(nombrePersona[0]), \(dictGeo["lat"]!), \(dictGeo["lng"]!)")
                        }
                        
                    }
                }
            }
            catch {
                print("Ha ocurrido un error")
            }
            
        }
        view.addSubview(tableView)
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.listaAux.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let celda = tableView.dequeueReusableCellWithIdentifier("Cell", forIndexPath: indexPath)
        celda.textLabel?.text = self.listaAux[indexPath.row]
        return celda
    }

}
